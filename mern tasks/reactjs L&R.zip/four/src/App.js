/*import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;*/
import {Col,Container,Row,Button,Form} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.css'; 


function App() {
  return (
<Container>
    <Row>
      <Col className='log'>
      <Form>
      <h1> LOGIN FORM </h1>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Email address</Form.Label>
        <Form.Control type="email" placeholder="Enter email" />
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Password</Form.Label>
        <Form.Control type="password" placeholder="Password" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicCheckbox">
      <Form.Label>Captcha</Form.Label>
        <Form.Control type="Captcha" placeholder="Captcha"  />
      </Form.Group>
      <Button variant="info" type="submit">
        Submit
      </Button>
      </Form>
      </Col>
     <Col >
      <Form>
       <h1> REGISTER FORM </h1>
       <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Name</Form.Label>
        <Form.Control type="name" placeholder="name" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Email </Form.Label>
        <Form.Control type="email" placeholder="Enter email" />
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Password</Form.Label>
        <Form.Control type="password" placeholder="Password" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Confirm Password</Form.Label>
        <Form.Control type="Confirm Password" placeholder="Confirm Password" />
      </Form.Group>
      <Button variant="info" type="submit" >Register</Button>
      </Form>
      </Col>
    </Row>
</Container>
  );
}
export default App;
